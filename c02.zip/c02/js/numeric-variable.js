var price;

var quantity;

var total;
// Create three variables to store the information needed.

// Assign values to the price and quality variables.

price = 5;
quantity = 14;

// Calculate the total by multiplying the price by quantity.

total= price * quantity;

// Get the element with an id of cost.

var el = document.getElementById( 'cost');
 el.textContent = '$' + total;
