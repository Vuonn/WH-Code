var title;
var message;

// Assign values to these variables.

title = "Molly's Special Offers";

message= '<a href=\"sale.html\">25% off!</a>';

// Get the element with an id of title.

var elTitle = document.getElementById( 'title'); 
//Replace the content of this element.

ette.textContent = title;

//Get the erent with an id of note
 var elNote = document.getElementById(  'note');
elNote.innerHTML = message;