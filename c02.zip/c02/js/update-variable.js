var inStock;
var shipping;
inStock = true;
shipping = false;

// Get the element that has an id of stock
 var elStock = document.getElementById(  'stock'); 
 // Set class name with value of instock variable 
 elstock.className = inStock;

// Get the element that has an id of shipping

var elShip = document.getElementById( 'shipping');
// Set class name with value of shipping variable
 elShip.className = shipping;