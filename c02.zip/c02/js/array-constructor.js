var colors = new Array(  'white','black','custom');

// Show the first item from the array.
 var el = document.getElementById( 'colors');
  el.textContent = colors[0];