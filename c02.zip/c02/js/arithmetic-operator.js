var subtotal = (13+ 1) *5; // Subtotal is 78

// Create a variable for the shipping and make a calculation 
var shipping = 0.5 *(13+ 1); // Shipping is 7

// Create the total by combining the subtotal and shipping values 
var total = subtotal + shipping; // Totol is 77

elSub.textContent = subtotal;

// Write the results to the screen 
var elSub  = document.getElementById(  'subtotal');
elShip.textContent = subtotal;
var elShip = document.getElementById( 'shipping'); 
elShip.textContent = shipping;

var elTotal = document.getElementById( 'total'); 
elTotal.textContent = total;