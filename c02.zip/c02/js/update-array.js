var color = ('wbite', 'black', 'custom');

colors[2] = 'beige';

var el = document.getElementById( 'colors');
el.textContent = colors[2];

